;
;
;             ***************************************************************************************
;	       	  *********  ******  ******        *****  *  *****  *  *****        *****   ******  ********
;		   ************  ****  *******  ******  ****  *  *****  *  ****  ******  ****  *  ****  **************
;		         ******  **  *********  ******  ****  ***  *  ***  ****  ******  ****  **  ***  *************
;		     **********       ********  ******  ****  ****   ****  ****  ******  ****  ***  **  ***********
;		   ************  ****  *******  ******  ****  ***** *****  ****  ******  ****  ****  *  **************
;		    ***********  ******  *****  ******  ****  ***********  ****  ******  ****  ******   *******
;		    ***********  *******   ****        *****  ***********  *****        *****  *******  **********
;		  ****************************************************************************************************

;************************************************************************************************************************************

;											        koMon 28.02.2018

;************************************************************************************************************************************

													 (vl-load-com)

;************************************************************************************************************************************

(defun get_corrected_angle (input_angle / output_angle)
  	(cond
  	  		(
  			 	(and
  				  (or (> input_angle 0.0) (equal input_angle 0.0 1e-10))
  				  (or (< input_angle (/ pi 2)) (< (- input_angle (/ pi 2)) 1e-10))
  			  	)
  			 		(setq output_angle (+ input_angle (/ pi 2)))
  			)
  			(
  				(and
  				  (or (> input_angle pi) (< (- input_angle pi) 1e-10))
  				  (or (< input_angle (+ pi (/ pi 2))) (< (- input_angle (+ pi (/ pi 2))) 1e-10))
  			  	)
  				  	(setq output_angle (- input_angle (/ pi 2)))
  			)
  			(
  				(and
  				  (> input_angle (/ pi 2))
  				  (< input_angle pi)
  			  	)
  				  	(setq output_angle (- input_angle (/ pi 2)))
  			)
  				(
  				(and
  				  (> input_angle (+ pi (/ pi 2)))
  				  (< input_angle (* pi 2))
  			  	)
  				  	(setq output_angle (+ input_angle (/ pi 2)))
  			)
	)
)

;************************************************************************************************************************************

(defun get_pline ( / is_selecting_polyline entsel_return entsel_data polyline_object)
	(setq is_selecting_polyline t)
	(while is_selecting_polyline
		(setq entsel_return (type (setq entsel_data (vl-catch-all-apply 'EntSel (list "\nSelect Polyline or Press ESC to Cancel ")))))
		(cond
			(
				(= entsel_return 'LIST)
					(cond
						(
						 	(member (vla-get-objectname (setq polyline_object (vlax-ename->vla-object (car entsel_data)))) (list "AcDbPolyline" "AcDb2dPolyline"))
						 		(setq is_selecting_polyline nil)
						)
							(
								t
									(princ "\nWrong Selection! ")

							)
					)
			)
			(
				(= entsel_return 'VL-CATCH-ALL-APPLY-ERROR)
					(setq is_selecting_polyline nil)
			)
			(
				t
					(princ "\nNothing is Selected! ")

			)
		)
	)
	polyline_object
)

;************************************************************************************************************************************

(defun c:Block_Along_PLine ()

	(setq block_ALong_Pline_Vars '(
									Acad_Object All_Attributes_List Aux_Get_Angle_Point Aux_Start_Angle_Point Blocks_List Block_Name Block_Number
		  							Block_Point blocks_processed Block_Uniscale Crossing_Window_Sset_Object Current_Distance Current_Footing_Block Current_Footing_Block_Angle
		  							Current_Line Current_Relative_Distance Current_String Distances_File Distance_File_Path Distance_From_Beginning Document_Object
		  							Document_Selection_Sets Dwg_Blocks_Collection Error_Occured File_To_Open Footings_Processed Footing_Block_Added Footing_Block_Attribute_Object
		  							Footing_Block_Circle_Object Footing_Block_Is_Defined Footing_Block_Name Has_Name Has_Number Insertion_Point Intersections_Number
		  							Intersection_Points_Array Is_Zoomed_Out Is_Zoommed_Out Left_Lower_Corner Modelspace_Object Objects_To_Remove Objects_To_Remove_List
		  							Polyline_Start_Flag_Array Polyline_Start_Flag_Object Previous_Relative_Distance Right_Upper_Corner Segment_0_End_Width Screen_Center_Units
									Screen_Height_Units Screen_Llc Screen_Ruc Screen_Size_Pixels Screen_Width_Units Segment_0_Start_Width Selected_Index Start_Flag_Angle
									Target_Polyline	Target_Polyline_Start_Point There_Is_Crossing_Window_Sset Vla_Method_Executed Width_Multiplier Current_Line_Char_List
									Current_String_Char_List Read_Data_List File_To_Open_Is_Txt selected_export_file
								   )
		  target_polyline (get_pline)
	)
	(and target_polyline
		(progn
			(setq acad_Object (vlax-get-acad-object)
				  document_object (vla-get-ActiveDocument acad_Object)
				  modelSpace_object (vla-get-ModelSpace document_Object)
				  Distance_File_Path (strcat (vlax-get document_object 'Path) "\\")
				  document_Selection_sets (vla-get-SelectionSets document_object)
				  there_is_Crossing_Window_Sset nil
				  polyline_start_flag_array (vlax-make-safearray vlax-vbDouble '(0 . 11))
				  vla_method_executed (vlax-safearray-fill polyline_start_flag_array '(0 0 0 10 8 10 5 7.5 8 5 0 5))
				  polyline_start_flag_object (vla-AddLightWeightPolyline modelSpace_object polyline_start_flag_array)
				  target_polyline_start_point (list (car (vlax-get target_polyline 'Coordinates)) (cadr (vlax-get target_polyline 'Coordinates)))
				  aux_start_angle_point (vlax-3d-point (vlax-curve-getPointAtDist target_polyline 0.1))
				  start_flag_angle (vla-AngleFromXAxis (vla-get-Utility document_object) (vlax-3d-point target_polyline_start_point) aux_start_angle_point)
				  vla_method_executed (vla-Move polyline_start_flag_object (vlax-3d-point 0 0 0) (vlax-3d-point target_polyline_start_point))
				  vla_method_executed (vla-Rotate polyline_start_flag_object (vlax-3d-point target_polyline_start_point) start_flag_angle)
				  vla_method_executed (vla-GetWidth target_polyline 0 'Segment_0_Start_Width 'Segment_0_End_Width)
				  block_uniscale (if (and (not (zerop Segment_0_Start_Width)) (> Segment_0_Start_Width 10)) (/ Segment_0_Start_Width 5) 1)
				  vla_method_executed (vla-ScaleEntity polyline_start_flag_object (vlax-3d-point target_polyline_start_point) block_uniscale)
				  vla_method_executed (vla-GetBoundingBox target_polyline 'left_lower_corner 'right_upper_corner)
				  screen_center_units (getvar "VIEWCTR")
				  screen_height_units (getvar "VIEWSIZE")
				  screen_size_pixels (getvar "SCREENSIZE")
				  width_multiplier (/ (car screen_size_pixels)  (cadr screen_size_pixels))
				  screen_width_units (* screen_height_units width_multiplier)
				  screen_llc (list (- (car screen_center_units) (/ screen_width_units 2.0)) (- (cadr screen_center_units) (/ screen_height_units 2.0)))
				  screen_ruc (list (+ (car screen_center_units) (/ screen_width_units 2.0)) (+ (cadr screen_center_units) (/ screen_height_units 2.0)))
			)
			(if (or
					(< (car (vlax-safearray->list left_lower_corner)) (car screen_llc))
					(< (cadr (vlax-safearray->list left_lower_corner)) (cadr screen_llc))
					(> (car (vlax-safearray->list left_lower_corner)) (car screen_llc))
					(> (cadr (vlax-safearray->list left_lower_corner)) (cadr screen_llc))
				)
					(progn
						(vla-ZoomWindow acad_Object left_lower_corner right_upper_corner)
						(setq is_zoommed_out t)
					)
			)
			(vlax-for selection_set document_Selection_sets
				(if (= "Crossing_Window_Sset" (vla-get-name selection_set))
					(setq there_is_Crossing_Window_Sset t
						  Crossing_Window_sset_Object selection_set
					)
				)
			)
			(if there_is_Crossing_Window_Sset
				(progn
					(vla-delete Crossing_Window_sset_Object)
					(vlax-release-object Crossing_Window_sset_Object)
					(setq Crossing_Window_sset_Object (vla-Add document_Selection_sets "Crossing_Window_Sset"))
				)
				(setq Crossing_Window_sset_Object (vla-Add document_Selection_sets "Crossing_Window_Sset"))
			)
			(vla-Select Crossing_Window_sset_Object acSelectionSetCrossing left_lower_corner right_upper_corner)

;######################################################
			(vlax-for Crossing_Window_sset_Object_item Crossing_Window_sset_Object (print Crossing_Window_sset_Object_item))
			(print "********************************************")
			(princ)
;######################################################

			(if is_zoommed_out (setq vla_method_executed (vla-ZoomPrevious acad_Object) is_zoomed_out nil))
			(setq objects_to_remove_list '()
				  selected_index 0
			)
			(repeat (vla-get-count Crossing_Window_sset_Object)
				(if (/= "AcDbBlockReference" (vla-get-objectname (vla-item Crossing_Window_sset_Object selected_index)))
					(setq objects_to_remove_list (cons (vla-item Crossing_Window_sset_Object selected_index) objects_to_remove_list))
					(progn (setq intersection_Points_array (vl-catch-all-apply 'vla-IntersectWith (list target_polyline (vla-item Crossing_Window_sset_Object selected_index) acExtendNone)))
						(if (or
								(= (type intersection_Points_array) 'VL-CATCH-ALL-APPLY-ERROR)
								(< (setq intersections_number (vlax-safearray-get-u-bound (vlax-variant-value intersection_Points_array) 1)) 0)
							)
								(setq objects_to_remove_list (cons (vla-item Crossing_Window_sset_Object selected_index) objects_to_remove_list))
						)
					)
				)
				(setq selected_index (1+ selected_index))
			)

;######################################################
					(foreach objects_to_remove_list_member objects_to_remove_list (print objects_to_remove_list_member))
					(print "********************************************")
					(princ)
;######################################################

			(setq objects_to_remove (vlax-make-safearray vlax-vbObject (cons 0 (1- (length objects_to_remove_list))))
				  selected_index 0
			)
			(repeat (length objects_to_remove_list)
				(vlax-safearray-put-element objects_to_remove selected_index (nth selected_index objects_to_remove_list))
				(setq selected_index (1+ selected_index))
			)
			(vla-RemoveItems Crossing_Window_sset_Object objects_to_remove)
			(if (not (zerop (vla-get-count Crossing_Window_sset_Object)))

				(progn		;<+++++++++++++++++++++export code +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					(setq blocks_list '())
					(vlax-for block_item Crossing_Window_sset_Object
						(setq block_point (vlax-curve-getClosestPointTo target_polyline (vlax-safearray->list (vlax-variant-value (vla-get-insertionpoint block_item))))
							  vla_method_executed (vla-put-insertionpoint block_item (vlax-3d-point block_point))
							  blocks_list (cons (list (vlax-curve-getdistatpoint target_polyline block_point) block_item) blocks_list)
						)
					)
					(setq blocks_list (vl-sort blocks_list
									  		(function (lambda (element_1 element_2)
															(< (car element_1) (car element_2))
													  )
											)
									  )
					)

;######################################################
					(foreach blocks_list_member blocks_list (print blocks_list_member))
					(princ)
;######################################################

					(if (null (vlax-ldata-list modelSpace_object))
						(vlax-ldata-put modelSpace_object "Distance_File_Path" Distance_File_Path)
						(if (not (vl-file-directory-p (cdr (assoc "Distance_File_Path" (vlax-ldata-list modelSpace_object)))))
							(vlax-ldata-put modelSpace_object "Distance_File_Path" Distance_File_Path)
							(setq Distance_File_Path (cdr (assoc "Distance_File_Path" (vlax-ldata-list modelSpace_object))))
						)
					)
					(setq is_selected_export_file nil)
					(while (not is_selected_export_file)
						(setq file_to_open (getfiled "Enter Distances Data File Name to Write to" Distance_File_Path "csv" 3))
						(if file_to_open (if (null (setq distances_file (open file_to_open "w"))) (alert "Selected file is Locked! \nEnter Another Name.") (setq is_selected_export_file t)) (setq is_selected_export_file t))
					)
					(if file_to_open
						(progn
							(setq previous_relative_distance 0.0
								  blocks_processed 1
								  vla_method_executed (vlax-ldata-put modelSpace_object "Distance_File_Path" (strcat (vl-filename-directory file_to_open) "\\"))
							)
							(write-line "�/� �����;�������-�����_�����;�������-��������;���. ����������;���. ���������" distances_file)
							(foreach block_item blocks_list
								(setq current_relative_distance (- (car block_item) previous_relative_distance)
									  previous_relative_distance (car block_item)
									  all_attributes_list '()
									  all_attributes_list (if (= :vlax-true (vla-get-hasattributes (cadr block_item))) (vlax-safearray->list (vlax-variant-value (vla-getattributes (cadr block_item)))))
									  has_number nil
									  has_name nil
									  all_attributes_list (if all_attributes_list (vl-remove-if-not
																						(function
																							(lambda (attribute_item)
																								(or
																									(and (= "�����_�����" (vla-get-TagString attribute_item)) (setq has_number t) (setq block_number (vla-get-TextString attribute_item)))
																									(and (= "��������" (vla-get-TagString attribute_item)) (setq has_name t) (setq block_name (vla-get-TextString attribute_item)))
																								)
																							)
																						)
																						all_attributes_list
																				  )
														   )
								)
								(setq current_line (strcat (itoa blocks_processed) ";" (if has_number block_number "None") ";" (if has_name block_name "None") ";" (rtos current_relative_distance) ";" (rtos (car block_item))))
								(write-line current_line distances_file)
								(setq blocks_processed (1+ blocks_processed))
							)
							(princ (strcat "\nTotal of " (itoa (1- blocks_processed)) " Blocks Were Processed"))
							(close distances_file)
						)
						(setq vla_method_executed (vla-erase polyline_start_flag_object)
							  error_occured	(princ "\nYou've Just Cancelled the Command!")
						)
					)
				)			;<+++++++++++++++++++++export code +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

				(progn 		;<+++++++++++++++++++++import code +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					(setq dwg_blocks_collection (vla-get-Blocks document_Object)
						  Distance_File_Path (strcat (vlax-get document_object 'Path) "\\")
						  distance_from_beginning 0.0
						  footing_block_name "�����"
						  footing_block_is_defined nil
					)
					(vlax-for collection_block dwg_blocks_collection
						(if (= (vla-get-name collection_block) footing_block_name)
							(setq footing_block_is_defined t)
						)
					)
																			;	attribute height 2.5
																			;	attribute mode acAttributeModeVerify
																			;	attribute prompt "����� �����"
																			;	attribute insertion point 0.0 0.0 0.0
																			;	attribute tag "�����_�����"
																			;	atribute value "&"
					(if (not footing_block_is_defined)
						 (setq footing_block_added (vla-Add dwg_blocks_collection (vlax-3d-point 0 0 0) "�����")
							   footing_block_circle_object (vla-AddCircle footing_block_added (vlax-3d-point 0 0 0) 5.0)
							   footing_block_attribute_object (vla-AddAttribute footing_block_added 2.5 acAttributeModeVerify "����� �����" (vlax-3d-point 0.0 0.0 0.0) "�����_�����" "&")
							   vla_method_executed (vla-put-alignment footing_block_attribute_object 1)
							   vla_method_executed (vla-put-TextAlignmentPoint footing_block_attribute_object (vlax-3d-point 0.0 10.0 0.0))
						 )
					)
					(if (null (vlax-ldata-list modelSpace_object))
						(vlax-ldata-put modelSpace_object "Distance_File_Path" Distance_File_Path)
						(if (not (vl-file-directory-p (cdr (assoc "Distance_File_Path" (vlax-ldata-list modelSpace_object)))))
							(vlax-ldata-put modelSpace_object "Distance_File_Path" Distance_File_Path)
							(setq Distance_File_Path (cdr (assoc "Distance_File_Path" (vlax-ldata-list modelSpace_object))))
						)
					)
					(if (setq file_to_open (getfiled "Select Footing Data File to Read from" Distance_File_Path "txt;csv" 16))
						(progn
							(setq distances_file (open file_to_open "r")
								  vla_method_executed (vlax-ldata-put modelSpace_object "Distance_File_Path" (strcat (vl-filename-directory file_to_open) "\\"))
								  file_to_open_is_txt (if (= (strcase (vl-filename-extension file_to_open) t) ".txt") t nil)
							)
							(setq current_string (read-line distances_file)
								  footings_processed 1
							)
							(while current_string
								(setq current_distance (if file_to_open_is_txt
															(atof current_string)
															(progn
																(setq current_string_char_list (vl-string->list current_string)
      																  read_data_list '()
																)
																(while (setq delimiter_position (vl-position 59 current_string_char_list))
  																	(setq read_data_list (cons (substr current_string 1 delimiter_position) read_data_list)
																		  current_string_char_list (cdr (member 59 current_string_char_list))
																		  current_string (vl-list->string current_string_char_list)
  																	)
																)
																(setq read_data_list (reverse (cons current_string read_data_list)))
																(atof (cadddr read_data_list))
															)
													   )
									  distance_from_beginning (+ distance_from_beginning current_distance)
									  insertion_point (vlax-curve-getPointAtDist target_polyline distance_from_beginning)
								)
								(if insertion_point
									(if (not (zerop current_distance))
										(progn
											(setq aux_get_angle_point (vlax-3d-point (vlax-curve-getPointAtDist target_polyline (- distance_from_beginning 0.1)))
												  current_footing_block_angle (vla-AngleFromXAxis (vla-get-Utility document_object) aux_get_angle_point (vlax-3d-point insertion_point))
												  current_footing_block (vla-InsertBlock modelSpace_object (vlax-3d-point insertion_point) footing_block_name block_uniscale block_uniscale 1 current_footing_block_angle)
												  all_attributes_list (vlax-safearray->list (vlax-variant-value (vla-getattributes current_footing_block)))
												  current_string (read-line distances_file)
											)
											(foreach attribute_item all_attributes_list
												(if (= "�����_�����" (vla-get-TagString attribute_item))
													(setq vla_method_executed (vla-put-TextString attribute_item (strcat "�" (itoa footings_processed)))
														  vla_method_executed (vla-put-Rotation attribute_item 0.0)
														  vla_method_executed (if (= 1 (vla-get-Alignment attribute_item))
																	  				(vla-put-TextAlignmentPoint attribute_item (vlax-3d-point (polar insertion_point (get_corrected_angle current_footing_block_angle) (* block_uniscale 10.0))))
																					(setq vla_method_executed (vla-put-Alignment attribute_item 1)
																						  vla_method_executed (vla-put-TextAlignmentPoint attribute_item (vlax-3d-point (polar insertion_point (get_corrected_angle current_footing_block_angle) (* block_uniscale 10.0))))
																					)
																			  )

													)
												)
											)
											(setq footings_processed (1+ footings_processed))
										)
										(setq current_string (read-line distances_file))
									)
									(setq current_string nil
										  error_occured (princ "\nNot Enough Length of Polyline to Place all Footings!")
									)
								)
  							)
  							(close distances_file)
							(princ (strcat "\nTotal of " (itoa (1- footings_processed)) " Footings Were Processed"))
						)
						(setq vla_method_executed (vla-erase polyline_start_flag_object)
							  error_occured	(princ "\nYou've Just Cancelled the Command!")
						)
					)
				)		;<+++++++++++++++++++++import code +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
			)
		)
	)
	(if (null target_polyline) (princ "\nYou've Just Cancelled the Command!"))
	(foreach nth_var block_ALong_Pline_Vars (set nth_var nil))
	(setq block_ALong_Pline_Vars nil)
	(princ)
)

;************************************************************************************************************************************
