(defun c:expl-p ()
 (vl-load-com)
 (vlax-for b (vla-get-Blocks
 (vla-get-ActiveDocument (vlax-get-acad-object))
 )
 (or (wcmatch (vla-get-Name b) "`**_Space*")
 (vla-put-explodable b :vlax-true)         ;<-switch to false should do it?
 )
 )
 (princ)
 )