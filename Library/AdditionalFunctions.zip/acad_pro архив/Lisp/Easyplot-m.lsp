(vl-load-com)

(defun c:easyplot-m (/               mgetboundingbox plotter-format-dialog           table
                   _dwgru-conv-pickset-to-list     ent             ss              str             adoc
                   box             lay             cp              m1              m2              plot_paper_name
                   plot            dcl_cp          scale
                   )

  (defun mgetboundingbox (ename / getboundingbox getboundingbox_dynblock spline_getboundingbox)

    (defun getboundingbox (en / obj minpt maxpt)
      (if (= (type en) 'ename)
        (progn
          (setq cp "2")
          (setq m1 "1")
          (setq m2 "1")
          (setq obj (vlax-ename->vla-object en))
          (vla-getboundingbox obj 'minpt 'maxpt)
          (list
            (vlax-safearray->list minpt)
            (vlax-safearray->list maxpt)
            ) ;_ end of list
          ) ;_ end of progn
        ) ;_ end of if
      ) ;_ end of defun

    (defun getboundingbox_dynblock
                                   (ent / lst ins_pt min_point max_point 3d_polarp)
                                   ;|
(entmakex
 (cons '(0 . "LINE")
       (mapcar 'cons '(10 11) (getboundingbox_dynblock nil))
 ) ;_ end of append
) ;_ end of entmakex
|;
      (if
        (and (or ent
                 (= (type (setq ent (vl-catch-all-apply
                                      (function
                                        (lambda ()
                                          (car (entsel "\n���� <������> : "))
                                          ) ;_ end of lambda
                                        ) ;_ end of function
                                      ) ;_ end of vl-catch-all-apply
                                ) ;_ end of setq
                          ) ;_ end of type
                    'ename
                    ) ;_ end of =
                 ) ;_ end of or
             (setq ent (vlax-ename->vla-object ent))
             (vlax-property-available-p ent 'isdynamicblock)
             (equal (vla-get-isdynamicblock ent) :vlax-true)
             ) ;_ end of and
         (progn
           (vlax-for item
                          (vla-item
                            (vla-get-blocks
                              (vla-get-activedocument (vlax-get-acad-object))
                              ) ;_ end of vla-get-blocks
                            (vla-get-name ent)
                            ) ;_ end of vla-item
             (if (equal (vla-get-visible item) :vlax-true)
               (setq lst (cons item lst))
               ) ;_ end of if
             ) ;_ end of vlax-for
           (setq
             ins_pt (vlax-safearray->list
                      (vlax-variant-value
                        (vla-get-insertionpoint ent)
                        ) ;_ end of vlax-variant-value
                      ) ;_ end of vlax-safearray->list
             lst
                    (vl-remove
                      nil
                      (mapcar
                        (function
                          (lambda (x / minp maxp)
                            (if
                              (not (vl-catch-all-error-p
                                     (vl-catch-all-apply
                                       (function
                                         (lambda ()
                                           (vla-getboundingbox x 'minp 'maxp)
                                           ) ;_ end of lambda
                                         ) ;_ end of function
                                       ) ;_ end of vl-catch-all-apply
                                     ) ;_ end of vl-catch-all-error-p
                                   ) ;_ end of not
                               (list (cons "min" (vlax-safearray->list minp))
                                     (cons "max" (vlax-safearray->list maxp))
                                     ) ;_ end of list
                               ) ;_ end of if
                            ) ;_ end of lambda
                          ) ;_ end of function
                        lst
                        ) ;_ end of mapcar
                      ) ;_ end of vl-remove
             lst    (mapcar
                      (function
                        (lambda (mins)
                          (mapcar
                            (function
                              (lambda (fun)
                                (apply
                                  (read mins)
                                  (mapcar
                                    (function fun)
                                    (mapcar
                                      (function
                                        (lambda (pts)
                                          (cdr (assoc mins pts))
                                          ) ;_ end of lambda
                                        ) ;_ end of function
                                      lst
                                      ) ;_ end of mapcar
                                    ) ;_ end of mapcar
                                  ) ;_ end of apply
                                ) ;_ end of lambda
                              ) ;_ end of function
                            (list car cadr caddr)
                            ) ;_ end of mapcar
                          ) ;_ end of lambda
                        ) ;_ end of function
                      (list "min" "max")
                      ) ;_ end of mapcar
             lst    (mapcar
                      (function
                        (lambda (ept)
                          (mapcar
                            (function
                              (lambda (coord_pt coord_line coord_ins)
                                (+
                                  (*
                                    coord_pt
                                    ((eval
                                       (read (strcat "vla-get-"
                                                     coord_line
                                                     "EffectiveScaleFactor"
                                                     ) ;_ end of strcat
                                             ) ;_ end of read
                                       ) ;_ end of eval
                                      ent
                                      )
                                    ) ;_ end of *
                                  coord_ins
                                  ) ;_ end of +
                                ) ;_ end of lambda
                              ) ;_ end of function
                            ept
                            '("X" "Y" "Z")
                            ins_pt
                            ) ;_ end of mapcar
                          ) ;_ end of lambda
                        ) ;_ end of function
                      lst
                      ) ;_ end of mapcar
             ) ;_ end of setq
           ) ;_ end of progn
         ) ;_ end of if
      ) ;_ end of defun

    (defun spline_getboundingbox (obj / c_pt_lst cd_pt_lst ex_pt_lst cls_pt_lst p_lst divid spline_extr)
      (defun spline_extr (obj pst / it)
                         ;|
������� ������ ���������� ������� �� ������ ������ �������.
�������� ���������:
 obj - VLA-OBJECT ��� ENAME ����: #<VLA-OBJECT IAcadSpline 05548644>
��� <Entity name: 7ef65fb8>
 pst - �������� ������� � ����� ���������� ����������� � ����������,
�������������� �����

������������ ��������:
 ������ ����: (��������1 ��������2 ��������3)
 �������� 1(2,3) ����� ���� �������������� ������������� ������ ���
nil, ���� ���������
 �� ��� ������ (����� �� �������).
 �������: (137.199 173.728 147.543)
         (nil nil 219.258)

������ ������:
(spline_extr
 (setq obj
        (vlax-ename->vla-object
          (car (entsel "\n�������� ������:"))
        ) ;_ end of vlax-ename->vla-object
 ) ;_ end of setq
 (vlax-curve-getParamAtPoint
   obj
   (getpoint "\n������� ����� �� �������:")
 ) ;_ end of vlax-curve-getParamAtPoint
) ;_ end of spline_extr
|;
        (if pst
          (mapcar
            (function
              (lambda (cadrs / f df p)
                (setq it 0
                      p  pst
                      ) ;_ end of setq
                (while (not (or (equal f 0.0 1.0e-008)
                                (equal df 0.0 1.0e-008)
                                (> it 10)
                                ) ;_ end of or
                            ) ;_ end of not
                  (setq it (1+ it)
                        f  ((eval cadrs) (vlax-curve-getfirstderiv obj p))
                        df ((eval cadrs) (vlax-curve-getsecondderiv obj p))
                        p  (if (equal df 0.0 1.0e-008)
                             p
                             (- p (/ f df))
                             ) ;_ end of if
                        ) ;_ end of setq
                  ) ;_ end of while
                (if (or (< p (vlax-curve-getstartparam obj))
                        (> p (vlax-curve-getendparam obj))
                        (> it 10)
                        ) ;_ end of or
                  nil
                  p
                  ) ;_ end of if
                ) ;_ end of lambda
              ) ;_ end of function
            (list car cadr caddr)
            ) ;_ end of mapcar
          ) ;_ end of if
        ) ;_ end of defun

      (defun divid (pt1 pt2 n)
                   ;|
   ������� ���������� �����, ������� �������
   �� �������� ���������� ������ ������.

�������� ���������:
   pt1 - ������ �������
   pt2 - ����� �������
   n - ���������� ������

������ ������:
   (divid '(0.0 0.0 0.0) '(15.0 15.0 15.0) 3)
   (divid '(0.0 0.0) '(12.0 12.0) 4)

������������ �������� - ������ ����� ����:
   ((5.0 5.0 5.0) (10.0 10.0 10.0))
   ((3.0 3.0) (6.0 6.0) (9.0 9.0))
|;
        (mapcar
          '(lambda (c)
             (mapcar '(lambda (a b) (+ (* c (/ (- a b) n)) b)) pt2 pt1)
             ) ;_ end of lambda
          (
           (lambda (d / rez)
             (repeat (setq d (1- d))
               (setq rez (cons d rez)
                     d   (1- d)
                     ) ;_ end of setq
               ) ;_ end of repeat
             rez
             ) ;_ end of lambda
            n
            )
          ) ;_ end of mapcar
        ) ;_ end of defun

      (if (= (type obj) 'ename)
        (setq obj (vlax-ename->vla-object obj))
        ) ;_ end of if
      (setq c_pt_lst   (mapcar
                         '(lambda (x)
                            (vlax-safearray->list
                              (vlax-variant-value
                                (vla-getcontrolpoint obj x)
                                ) ;_ end of vlax-variant-value
                              ) ;_ end of vlax-safearray->list
                            ) ;_ end of lambda
                         ((lambda (/ n lst)
                            (repeat
                              (1- (setq
                                    n (1- (vla-get-numberofcontrolpoints obj))
                                    ) ;_ end of setq
                                  ) ;_ end of 1-
                               (setq
                                 n   (1- n)
                                 lst (cons n lst)
                                 ) ;_ end of setq
                               ) ;_ end of repeat
                            lst
                            ) ;_ end of lambda
                          )
                         ) ;_ end of mapcar
            cd_pt_lst  ((lambda (lst / rez)
                          (while lst
                            (if (cadr lst)
                              (setq
                                rez (append
                                      rez
                                      (cons (car lst)
                                            (divid (car lst) (cadr lst) 3)
                                            ) ;_ end of cons
                                      ) ;_ end of append
                                ) ;_ end of setq
                              (setq rez (append rez lst))
                              ) ;_ end of if
                            (setq lst (cdr lst))
                            ) ;_ end of while
                          rez
                          ) ;_ end of lambda
                         c_pt_lst
                         )
            cls_pt_lst (mapcar
                         '(lambda (pt)
                            (vlax-curve-getclosestpointto obj pt)
                            ) ;_ end of lambda
                         cd_pt_lst
                         ) ;_ end of mapcar
            p_lst      (vl-remove-if
                         'not
                         (apply
                           'append
                           (mapcar
                             (function (lambda (x)
                                         (spline_extr
                                           obj
                                           (vlax-curve-getparamatpoint obj x)
                                           ) ;_ end of spline_extr
                                         ) ;_ end of lambda
                                       ) ;_ end of function
                             cls_pt_lst
                             ) ;_ end of mapcar
                           ) ;_ end of apply
                         ) ;_ end of vl-remove-if
            ex_pt_lst  (append
                         (list
                           (vlax-curve-getstartpoint obj)
                           (vlax-curve-getendpoint obj)
                           ) ;_ end of list
                         (mapcar
                           (function
                             (lambda (p) (vlax-curve-getpointatparam obj p))
                             ) ;_ end of function
                           p_lst
                           ) ;_ end of mapcar
                         ) ;_ end of append
            ) ;_ end of setq
      (mapcar
        (function
          (lambda (mins)
            (mapcar
              (function (lambda (cadrs)
                          (apply (function mins)
                                 (mapcar (function cadrs) ex_pt_lst)
                                 ) ;_ end of apply
                          ) ;_ end of lambda
                        ) ;_ end of function
              (list car cadr caddr)
              ) ;_ end of mapcar
            ) ;_ end of lambda
          ) ;_ end of function
        (list min max)
        ) ;_ end of mapcar
      ) ;_ end of defun

    (mapcar
      (function (lambda (a)
                  (mapcar (function (lambda (b)
                                      (if (equal b 0.0 1.0e-007)
                                        0.0
                                        b
                                        ) ;_ end of if
                                      ) ;_ end of lambda
                                    ) ;_ end of function
                          a
                          ) ;_ end of mapcar
                  ) ;_ end of lambda
                ) ;_ end of function
      (cond
        ((and
           (= (cdr (assoc 0 (entget ename))) "INSERT")
           (vlax-property-available-p
             (vlax-ename->vla-object ename)
             'isdynamicblock
             ) ;_ end of vlax-property-available-p
           (equal (vla-get-isdynamicblock (vlax-ename->vla-object ename))
                  :vlax-true
                  ) ;_ end of equal
           ) ;_ end of and
         (getboundingbox_dynblock ename)
         )
        ((= (cdr (assoc 0 (entget ename))) "SPLINE")
         (spline_getboundingbox ename)
         )
        (t (getboundingbox ename))
        ) ;_ end of cond
      ) ;_ end of mapcar
    ) ;_ end of defun

  (defun plotter-format-dialog (lay / easyplot-action-fun run_dialog fo fn plot_names paper_name)

    (defun easyplot-action-fun (key value data reason x y)
      (cond
        ((= key "plot_names")
         (setq plot_name (nth (atoi value) plot_names))
         (done_dialog 2)
         )
        ((= key "accept")
         (setq paper_name
                (cdr
                  (nth (atoi (get_tile "paper_names")) paper_names)
                  ) ;_ end of cdr
               ) ;_ end of setq
         (done_dialog 1)
         )
        ((= key "cancel") (setq paper_name 0) (done_dialog 3))
        ) ;_ end of cond
      ) ;_ end of defun

    (defun run_dialog (file dlg rexp action / dl1)
      (if (and (= (type file) (type dlg) 'str)
               (= (type rexp) 'list)
               ) ;_ end of and
        (if (> (setq dl1 (load_dialog file)) 0)
          (progn
            (if (new_dialog dlg dl1 action)
              (progn
                (if
                  (vl-catch-all-error-p (vl-catch-all-apply rexp))
                   (progn
                     (princ "\n������ � ���������!")
                     (term_dialog)
                     (unload_dialog dl1)
                     ) ;_ end of progn
                   (progn
                     (action_tile "cp" "(setq dcl_cp (atoi $value))")
                     (action_tile "m1" "(setq m1 (cond ($value (atof $value)) (t 1)))")
                     (action_tile "m2" "(setq m2 (cond ($value (atof $value)) (t 100.8)))")
                     (start_dialog)
                     (unload_dialog dl1)
                     ) ;_ end of progn
                   ) ;_ end of if
                ) ;_ end of progn
              (alert
                (strcat
                  "� �����: \"" file "\"\n�� ������� �������� �������:\n\""     dlg "\"")
                ) ;_ end of alert
              ) ;_ end of if
            ) ;_ end of progn
          (alert (strcat "����: \"" file "\" �� ������!"))
          ) ;_ end of if
        ) ;_ end of if
      ) ;_ end of defun

    (setq
      plot_names (vl-sort
                   (vl-remove-if
                     '(lambda (a)
                        (or (= (strcase a t) "none")
                            (wcmatch a "*.pc2")
                            ) ;_ end of or
                        ) ;_ end of lambda
                     (vlax-safearray->list
                       (vlax-variant-value (vla-getplotdevicenames lay))
                       ) ;_ end of vlax-safearray->list
                     ) ;_ end of vl-remove-if
                   '<
                   ) ;_ end of vl-sort
      plot_name  (car plot_names)
      fn         (vl-filename-mktemp "objpr" nil ".dcl")
      fo         (open fn "w")
      ) ;_ end of setq
    (write-line
      (strcat
        "print_device:dialog{label=\"����� ���������� ������\";"
        ":boxed_column {:text{label=\"�������� ������� ��� �������:\";}:popup_list{key=\"plot_names\";}"
        ":text{label=\"�������� ������/������ �����:\";}:popup_list{key=\"paper_names\";}" "}"
        ":row {alignment = right;:text{label=\"����� �����������:\";}:edit_box{key=\"cp\";edit_width=1; edit_limit=2; value=\"1\"; alignment=left; initial_focus=true;}" "}"
        ":row {alignment = right;:text{label=\"������� ������:\";}:spacer{width=5;}:edit_box{key=\"m1\"; edit_width=4; edit_limit=5;value=\"1\";}:text{label=\":\";}:edit_box{key=\"m2\"; edit_width=4;edit_limit=5; value=\"100.8\";}" "}" "ok_cancel;}")
      fo
      ) ;_ end of write-line
    (close fo)
    (while (not paper_name)
      (run_dialog fn
                  "print_device"
                  (function
                    (lambda ()
                      (start_list "plot_names")
                      (mapcar 'add_list plot_names)
                      (end_list)
                      (set_tile "plot_names" (itoa (vl-position plot_name plot_names)))
                      (vla-put-configname lay plot_name)
                      (setq paper_names (vl-sort (vl-remove-if '(lambda (y)
                                                                  (wcmatch (car y) "*Inches*,*Pixels*,~*A#*")
                                                                  ) ;_ end of lambda
                                                               (mapcar
                                                                 '(lambda (c)
                                                                    (cons (vla-getlocalemedianame lay c) c)
                                                                    ) ;_ end of lambda
                                                                 (vlax-safearray->list
                                                                   (vlax-variant-value
                                                                     (vla-getcanonicalmedianames lay)
                                                                     ) ;_ end of vlax-variant-value
                                                                   ) ;_ end of vlax-safearray->list
                                                                 ) ;_ end of mapcar
                                                               ) ;_ end of vl-remove-if
                                                 '(lambda (a b) (< (car a) (car b)))
                                                 ) ;_ end of vl-sort
                            ) ;_ end of setq
                      (start_list "paper_names")
                      (mapcar '(lambda (a) (add_list (car a)))
                              paper_names
                              ) ;_ end of mapcar
                      (end_list)
                      ) ;_ end of lambda
                    ) ;_ end of function
                  "(easyplot-action-fun  $key $value $data $reason $x $y)"
                  ) ;_ end of run_dialog
      ) ;_ end of while
    (vl-file-delete (findfile fn))
    (if (and (= (type paper_name) 'str) (/= (strlen paper_name) 0))
      (progn
        (vla-put-canonicalmedianame lay paper_name)
        (list plot_name paper_name)
        ) ;_ end of progn
      ) ;_ end of if
    ) ;_ end of defun

  (defun table (s / d r)
               ;|
����� � dwg.ru
written by Michael Puckett.
�����
(table "style")
(table "layer")
|;
    (while (setq d (tblnext s (null d)))
      (setq r (append r (list (cdr (assoc 2 d)))))
      ) ;_ end of while
    ) ;_ end of defun

  (defun _dwgru-conv-pickset-to-list (value / tab item)
    (repeat (setq tab  nil
                  item (sslength value)
                  ) ;_ end setq
      (setq tab (cons (ssname value (setq item (1- item))) tab))
      ) ;_ end repeat
    ) ;_ end defun

  (vl-load-com)
  (setq adoc (vla-get-activedocument (vlax-get-acad-object))
        lay  (vla-get-activelayout adoc)
        plot (vla-get-plot adoc)
        ) ;_ end of setq
  (if (ssget "_X" (list (cons 410 (getvar "ctab"))))
    (progn
      (while (not ent)
        (setq ent
               (vl-catch-all-apply
                 (function
                   (lambda ()
                     (initget "��������� ���� _Multy Block")
                     (entsel
                       "\n������� ������ ��� ������, ���[���������/ ����]:"
                       ) ;_ end of getkword
                     ) ;_ end of lambda
                   ) ;_ end of function
                 ) ;_ end of vl-catch-all-apply
              ) ;_ end of setq
        (cond
          ((not ent) (princ "\n������ �� �������!"))
          ((vl-catch-all-error-p ent) (setq ent "exit"))
          ((and (listp ent) (= (type (car ent)) 'ename))
           (setq ent (list (car ent)))
           )
          (;|(and (= (type ent) 'STR)|;
           (= ent "Multy") ;)
           (setq
             ss (vl-catch-all-apply
                  (function (lambda ()
                              (princ "\n�������� ������� ��� ������:")
                              (ssget)
                              ) ;_ end of lambda
                            ) ;_ end of function
                  ) ;_ end of vl-catch-all-apply
             ) ;_ end of setq
           (cond
             ((not ss) (princ "\n������ �� �������!"))
             ((vl-catch-all-error-p ss) (setq ent "exit"))
             (t
              (setq ent (_dwgru-conv-pickset-to-list ss))
              )
             ) ;_ end of cond
           )
          ((and (= (type ent) 'str) (= ent "Block"))
           (if
             (ssget "_X"
                    (list (cons 0 "INSERT") (cons 410 (getvar "ctab")))
                    ) ;_ end of ssget
              (progn
                (setq ent nil)
                (while (or (not ent) (= ent "Name"))
                  (if (/= ent "Name")
                    (setq ent
                           (vl-catch-all-apply
                             (function
                               (lambda ()
                                 (initget "��� _Name")
                                 (entsel "\n������� ���� ��� �������, ���:[���]"
                                         ) ;_ end of entsel
                                 ) ;_ end of lambda
                               ) ;_ end of function
                             ) ;_ end of vl-catch-all-apply
                          ) ;_ end of setq
                    ) ;_ end of if
                  (cond
                    ((not ent) (princ "\n������ �� �������!"))
                    ((vl-catch-all-error-p ent) (setq ent "exit"))
                    ((and (listp ent)
                          (= (type (car ent)) 'ename)
                          (= (cdr (assoc 0 (entget (car ent)))) "INSERT")
                          ) ;_ end of and
                     (setq
                       ent
                        (vl-remove-if
                          (function
                            (lambda (a)
                              (/= (vla-get-effectivename
                                    (vlax-ename->vla-object a)
                                    ) ;_ end of vla-get-EffectiveName
                                  (vla-get-effectivename
                                    (vlax-ename->vla-object (car ent))
                                    ) ;_ end of vla-get-EffectiveName
                                  ) ;_ end of /=
                              ) ;_ end of lambda
                            ) ;_ end of function
                          (_dwgru-conv-pickset-to-list
                            (ssget "_X"
                                   (list (cons 0 "INSERT")
                                         (assoc 410 (entget (car ent)))
                                         ) ;_ end of list
                                   ) ;_ end of ssget
                            ) ;_ end of _dwgru-conv-pickset-to-list
                          ) ;_ end of vl-remove-if
                       ) ;_ end of setq
                     )
                    ((and (listp ent)
                          (= (type (car ent)) 'ename)
                          (/= (cdr (assoc 0 (entget (car ent)))) "INSERT")
                          ) ;_ end of and
                     (princ "\n��������� �� �������� ������!")
                     )
                    ((= ent "Name")
                     (setq str
                            (vl-catch-all-apply
                              (function
                                (lambda ()
                                  (initget "?")
                                  (getstring t "\n������� ��� �����, ���:[?]")
                                  ) ;_ end of lambda
                                ) ;_ end of function
                              ) ;_ end of vl-catch-all-apply
                           ) ;_ end of setq
                     (cond
                       ((vl-catch-all-error-p str) (setq ent "exit"))
                       ((= str "?")
                        (princ "\n������ �������� ��������� �����:")
                        (foreach a (vl-sort (table "Block") '<)
                          (princ (strcat "\n\"" a "\""))
                          ) ;_ end of foreach
                        (textpage)
                        )
                       ((and (tblsearch "Block" str)
                             (setq
                               ss (ssget "_X"
                                         (list (cons 0 "INSERT")
                                               (cons 2 str)
                                               (cons 410 (getvar "ctab"))
                                               ) ;_ end of list
                                         ) ;_ end of ssget
                               ) ;_ end of setq
                             ) ;_ end of and
                        (setq
                          ent
                           (_dwgru-conv-pickset-to-list
                             ss
                             ) ;_ end of _dwgru-conv-pickset-to-list
                          ) ;_ end of setq
                        )
                       (t
                        (princ
                          "\n����� � ����� ������ � ������� ������� ���!"
                          ) ;_ end of princ
                        )
                       ) ;_ end of cond
                     )
                    ) ;_ end of cond
                  ) ;_ end of while
                ) ;_ end of progn
              (progn
                (setq ent nil)
                (princ "\n������� ������� �� �������� ������!")
                ) ;_ end of progn
              ) ;_ end of if
           ) ;_ end of cond
          ) ;_ end of cond
        ) ;_ end of while
      (if
        (and
          (not (and (= (type ent) 'str) (= ent "exit")))
          (setq plot_paper_name (plotter-format-dialog lay))
          ) ;_ end of and
         (progn
           (mapcar '(lambda (a) (vlax-put-property lay (car a) (cdr a)))
                   (list
                     (cons "PlotType" acdisplay)
                     (cons "CenterPlot" :vlax-true)
                     (cons "PaperUnits" acmillimeters)
                     (cons "PlotHidden" :vlax-false)
                     (cons "PlotViewportBorders" :vlax-false)
                     (cons "PlotViewportsFirst" :vlax-false)
                     (cons "PlotWithLineweights" :vlax-true)
                     (cons "UseStandardScale" :vlax-false)
                     ) ;_ end of list
                   ) ;_ end of mapcar
           (setq dcl_cp (cond (dcl_cp)
                              (t 1)
                              ) ;_ end of cond
                 ) ;_ end of setq
           (vla-setcustomscale lay
                               (cond (m1)
                                     ((get_tile "m1") (atof (get_tile "m1")))
                                     (t 1)
                                     ) ;_ end of cond
                               (cond (m2)
                                     ((get_tile "m2") (atof (get_tile "m2")))
                                     (t 100.8)
                                     ) ;_ end of cond
                               ) ;_ end of vla-setcustomscale
           (if (member "monochrome.ctb"
                       (vl-sort
                         (vl-remove-if
                           (function (lambda (a) (wcmatch a "*.stb")))
                           (vlax-safearray->list
                             (vlax-variant-value
                               (vla-getplotstyletablenames lay)
                               ) ;_ end of vlax-variant-value
                             ) ;_ end of vlax-safearray->list
                           ) ;_ end of vl-remove-if
                         (function <)
                         ) ;_ end of vl-sort
                       ) ;_ end of member
             (progn
               (vla-put-plotwithplotstyles lay :vlax-true) ;_ :vlax-false or :vlax-true
               (vla-put-stylesheet lay "monochrome.ctb")
               ) ;_ end of progn
             (progn
               (vla-put-plotwithplotstyles lay :vlax-false)
               ) ;_ end of progn
             ) ;_ end of if
           (vla-put-numberofcopies plot 1) 
           (foreach b ent
             (setq box (mgetboundingbox b))
             (vla-setwindowtoplot
               lay
               (vlax-safearray-fill
                 (vlax-make-safearray
                   vlax-vbdouble
                   '(0 . 1)
                   ) ;_ end of vlax-make-safearray
                 ((lambda (x) (list (car x) (cadr x)))
                   (car box)
                   )
                 ) ;_ end of vlax-safearray-fill
               (vlax-safearray-fill
                 (vlax-make-safearray
                   vlax-vbdouble
                   '(0 . 1)
                   ) ;_ end of vlax-make-safearray
                 ((lambda (x) (list (car x) (cadr x)))
                   (cadr box)
                   )
                 ) ;_ end of vlax-safearray-fill
               ) ;_ end of vla-SetWindowToPlot
             (vla-put-plottype lay acwindow)
             (vla-put-plotrotation
               lay
               (if
                 (apply
                   (function >)
                   (cdr
                     (reverse (mapcar (function -) (cadr box) (car box)))
                     ) ;_ end of cdr
                   ) ;_ end of apply
                  ac0degrees
                  ac90degrees
                  ) ;_ end of if
               ) ;_ end of vla-put-PlotRotation
             (
              (lambda (lst / var_lst cur_val_lst temp_val_lst)
                (setq var_lst      (mapcar (function car) lst)
                      temp_val_lst (mapcar (function cdr) lst)
                      cur_val_lst  (mapcar (function getvar) var_lst)
                      ) ;_ end of setq
                (mapcar (function setvar) var_lst temp_val_lst)
                (repeat (cond (dcl_cp)
                              (t 1)
                              ) ;_ end of cond
                  (vl-cmdf "_.plot" "_no" "" "" "" "_no" "_no" "_yes")
                  ) ;_ end of repeat
                (mapcar (function setvar) var_lst cur_val_lst)
                ) ;_ end of lambda
               (list (cons "cmdecho" 0))
               )
             ) ;_ end of foreach
           ) ;_ end of progn
         ) ;_ end of if
      ) ;_ end of progn
    (princ
      "\n������ ��������� ���������� - ������� ������� �� �������� ��������!"
      ) ;_ end of princ
    ) ;_ end of if
  (princ)
  ) ;_ end of defun