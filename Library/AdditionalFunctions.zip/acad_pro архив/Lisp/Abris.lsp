(defun C:ABRIS (/ bname attname _get-all-atts ss lst U_M pt1 pt2 str *error*)
;;;-------------------------------------------------------------------------------
;;;  
;;; Program Name: ABRIS
;;; Created By:   Vladimir Azarko (VVA)
;;; Url: http://forum.dwg.ru/showthread.php?t=81253
;;; Назначение: Рисование трассы по точкам, где номерами точек может выступать значение атрибута блока
;;; Settings: смотри значения bname и attname ниже
;;;  
;;; ==============================================================================;;
;;;                                                                               ;;
;;;  THIS PROGRAM AND PARTS OF IT MAY REPRODUCED BY ANY METHOD ON ANY             ;;
;;;  MEDIUM FOR ANY REASON. YOU CAN USE OR MODIFY THIS PROGRAM OR                 ;;
;;;  PARTS OF IT ABSOLUTELY FREE.                                                 ;;
;;;                                                                               ;;
;;;  THIS PROGRAM PROVIDES 'AS IS' WITH ALL FAULTS AND SPECIFICALLY               ;;
;;;  DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS                 ;;
;;;  FOR A PARTICULAR USE.                                                        ;;
;;;                                                                               ;;
;;; ==============================================================================;;
;;;  
;;;-------------------------------------------------------------------------------  
  (vl-load-com)
  (setq bname "*") ;_Здесь можно вписать имя блока
  (setq attname "NAME") ;_Имя атрибута блока
  (defun *error* (msg)
;;;Прерываем активную команду  
    (while (> (getvar "CMDACTIVE") 0) (command))
    (if	(and PICK1
	     (= (type PICK1) 'PICKSET)
             (> (sslength PICK1) 0)
             (setq pt1 (ssname PICK1 0))
	)
      (if (and (getvar "PEDITACCEPT")
	       (= (getvar "PEDITACCEPT") 1)
	  )
	(command "_PEDIT" pt1 "_J" PICK1 "" "")
	(command "_PEDIT" pt1 "_Y" "_J" PICK1 "" "")
      )
    )
    (setq PICK1 NIL)
    (while (> (getvar "CMDACTIVE") 0) (command))
    (princ msg)
    (princ)
  )
  (defun _get-all-atts (obj)
    (if (and obj
             (vlax-property-available-p obj 'Hasattributes)
             (eq :vlax-true (vla-get-hasattributes obj))
        ) ;_ end of and
      (vl-catch-all-apply
        (function
          (lambda ()
            (mapcar (function (lambda (x)
                                (cons (strcase (vla-get-tagstring x))
                                      (vla-get-textstring x)
                                ) ;_ end of cons
                              ) ;_ end of lambda
                    ) ;_ end of function
                    (append (vlax-invoke obj 'Getattributes)
                            (vlax-invoke obj 'Getconstantattributes)
                    ) ;_ end of append
            ) ;_ end of mapcar
          ) ;_ end of lambda
        ) ;_ end of function
      ) ;_ end of vl-catch-all-apply
    ) ;_ end of if
  ) ;_ end of defun
  (if
    (and
      (setq ss nil
            ss (ssget "_X"
                      (list
                        (cons 0 "INSERT")
                        (cons 2 bname)
                        (cons 66 1)
                        (cons 410 (getvar "CTAB"))
                      ) ;_ end of list
               ) ;_ end of ssget
      ) ;_ end of setq
      (setq lst
             (mapcar
               (function
                 (lambda (blk / attlist tmp)
                   (if (setq tmp (assoc attname (_get-all-atts blk)))
                     (cons (cdr tmp)
                           (vlax-safearray->list
                             (vlax-variant-value
                               (vla-get-insertionpoint blk)
                             ) ;_ end of vlax-variant-value
                           ) ;_ end of vlax-safearray->list
                     ) ;_ end of cons
                     nil
                   ) ;_ end of if
                 ) ;_ end of lambda
               ) ;_ end of function
               (mapcar (function vlax-ename->vla-object)
                       (vl-remove-if
                         (function listp)
                         (mapcar (function cadr) (ssnamex ss))
                       ) ;_ end of vl-remove-if
               ) ;_ end of mapcar
             ) ;_ end of mapcar
      ) ;_ end of setq
    ) ;_ end of and
     (progn
;;;=====================================      
       (setq ss  nil
             U_M (getvar "UNDOMARKS")
       ) ;_ end of setq
       (initget 128)
       (setq pt1 (getpoint "\nОт точки <выход> :"))
       (if (and pt1 (listp pt1)) ;_рисум линию
         (progn
           (setq PICK1 nil
                 PICK1 (ssadd)
           ) ;_ end of setq
           (setq str "\nК точке или номер <выход>:")
           (initget 128)
           (while (setq pt2 (getpoint pt1 str))
             (cond
               ((member pt2 '("О" "о" "_u" "_U" "u" "U"))
                (if (< U_M (getvar "UNDOMARKS"))
                  (progn
                    (command "_.UNDO" "_B")
                    (setq pt1 (list (getvar "USERR1") (getvar "USERR2")))
                  ) ;_ End of progn
                  (progn
                    (alert "Отменять больше нечего")
                  ) ;_ End of progn
                ) ;_ End of if
               )
               ((and pt2 (listp pt2))
                (setvar "USERR1" (car pt1))
                (setvar "USERR2" (cadr pt1))
                (command "_.UNDO" "_M")
;;;===Рисуем путь
                (command "_.LINE" "_none" pt1 "_none" pt2 "")
                (ssadd (entlast) PICK1)
                (setq pt1 pt2)
               )
               ((and pt2
                     (> (atoi (setq pt2 (vl-princ-to-string pt2))) 0)
                ) ;_ end of and
                (if (setq ss (cdr (assoc (strcase pt2) lst)))
;;;поиск номера точки
                  (progn
                    (setq pt2 (trans ss 0 1))
                    (setvar "USERR1" (car pt1))
                    (setvar "USERR2" (cadr pt1))
                    (command "_.UNDO" "_M")
;;;===Рисуем путь
                    (command "_.LINE" "_none" pt1 "_none" pt2 "")
                    (ssadd (entlast) PICK1)
                    (setq pt1 pt2)
                  ) ;_ end of progn
                  (princ (strcat "\nТочка с номером " pt2 "не найдена"))
                ) ;_ end of if
               )
               ((= (type pt2) 'STR) (princ " *** Непонятный ввод ***"))
               (t nil)
             ) ;_cond
             (setq str "\nК точке [Undo] <выход>:")
             (initget 128 "Отмена Undo _U _U")
           ) ;_ end of While
           (if (and (setq pt1 (ssname PICK1 0)) (entget pt1))
             (if (and (getvar "PEDITACCEPT")
                      (= (getvar "PEDITACCEPT") 1)
                 ) ;_ end of and
               (command "_PEDIT" pt1 "_J" PICK1 "" "")
               (command "_PEDIT" pt1 "_Y" "_J" PICK1 "" "")
             ) ;_ end of if
           ) ;_ end of if
         ) ;_ end of progn
       ) ;_ end of if
     ) ;_ end of progn
  ) ;_ end of if
  (setq PICK1 nil)
  (princ)
) ;_ end of defun