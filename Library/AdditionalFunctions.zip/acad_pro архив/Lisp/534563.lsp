(vl-load-com)
(defun c:b2l ( / name_of_bl dis pln dis_pl dis_run i krd prm_pnt
                 proiz ugol_pl ugol_pl_gr my_blok my_att spis_att
                 att_old att_new spis_att strt stp)
(command "_.undo" "_begin") 
(setq sc '("0.05" "0.10" "0.25" "0.50" "1.00" "2.50" "5.00"))
(setq bl '("BL1" "BL2" "BL3" "BL4" "BL5"))
(if(<(setq dcl_id(load_dialog"b2l"))0)(exit))
(if(not(new_dialog"b2l" dcl_id))(exit))
  (start_list "b1")				
  (mapcar 'add_list sc)				
  (end_list)
  (start_list "b2")				
  (mapcar 'add_list bl)				
  (end_list)
(action_tile"accept"						
     "(setq scl (atof (get_tile \"b1\")))	
      (setq blk (atof (get_tile \"b2\")))
      (setq dis (atof (get_tile \"ds_s\")))
      (setq strt (atoi(get_tile \"st_s\")))
      (setq stp  (atoi(get_tile \"sp_s\")))
      (setq atr  (atoi(get_tile \"att\")))
      (setq alg  (atoi(get_tile \"aln\")))
      (setq pref (get_tile \"pf_s\"))
      (setq suff (get_tile \"sf_s\"))
      (done_dialog)(setq userclick T))")		
(action_tile"cancel" "(done_dialog)(exit)")
(start_dialog)
(unload_dialog dcl_id)
(setq sc_s (nth (fix scl) sc))
(setq name_of_bl (nth (fix blk) bl))
(setq snp (getvar "Osmode"))
(setvar "Osmode" 0) 
(setq scl sc_s)
(if(not (tblsearch "layer"  name_of_bl))
(entmake(list '(0 . "LAYER" )'(100 . "AcDbSymbolTableRecord")
              '(100 . "AcDbLayerTableRecord")'(70 . 0)(cons 2 name_of_bl)'(62 . 7))))
(setvar "Clayer" name_of_bl)
(setq pln (car (entsel)))
(setq dis_pl (vlax-curve-getDistAtParam pln (vlax-curve-getEndParam pln)))
(setq dis_run (- 0.0 dis) i (- strt stp))
(while(< (+ dis_run dis) dis_pl)
 (progn
 (setq i (+ i stp))
 (setq dis_run (+ dis_run dis))
 (setq krd (vlax-curve-getPointAtDist pln dis_run))
 (setq prm_pnt  (vlax-curve-getParamAtPoint pln krd))
 (if(= alg 1)
    (progn
    (setq proiz (vlax-curve-getFirstDeriv pln prm_pnt))
    (setq ugol_pl (angle '(0 0 0) proiz))
    (setq ugol_pl_gr (* ugol_pl 57.29747))
    ) ;progn
    (setq ugol_pl_gr 0.0)
 ) ;if
 (setvar "attreq" 0)
 (command "_.insert" name_of_bl krd scl scl ugol_pl_gr)
 (if(= atr 1)
    (progn
    (setq my_blok (entlast))
    (setq my_att (entnext my_blok))
    (setq spis_att (entget my_att)) ;spisok 
    (setq att_old (assoc 1 spis_att)) ;name
    (setq num_new (itoa i))
    (setq num_new (strcat pref num_new suff))  
    (setq att_new (cons 1 num_new)) ;
    (setq spis_att (subst att_new att_old spis_att)); zamena
    (entmod spis_att)
    (entupd  (cdr (assoc -1 spis_att)))
    ) ;progn
  ) ;if
 ) ;progn
)
(setvar "Osmode" snp)
(command "_.undo" "_end") 
)