(vl-load-com) 
(defun in_bl (name_of_bl pln krd j dir / ugol_pl ugol_pl_gr )
(setq prm_pnt (+ j (* dir 0.1)))
(setq proiz (vlax-curve-getFirstDeriv pln prm_pnt))
(setq ugol_pl (angle '(0 0 0) proiz))
(setq ugol_pl_gr (* ugol_pl 57.29747))
(command "_.insert" name_of_bl krd 1.0 1.0 ugol_pl_gr)
)


(defun c:l2p ( / snp cmdh name_of_bl pln krd num j )
(command "_.undo" "_begin")
(setq snp (getvar "Osmode"))
(setq cmdh (getvar "CMDECHO"))
(setvar "Osmode" 0) 
(setvar "CMDECHO" 0)
(setq name_of_bl (getstring "\nName of blok?  "))
(setq pln (car (entsel)))
(setq krd (vlax-curve-getPointAtParam pln 0))
(in_bl name_of_bl pln krd 0.0 1.0)
(setq num (fix(-(vlax-curve-getEndParam pln) 1)))
(setq j 0)
(repeat num
   (setq j (1+ j))
   (setq krd (vlax-curve-getPointAtParam pln j))
   (in_bl name_of_bl pln krd j -1.0)
   (in_bl name_of_bl pln krd j 1.0)
)
(setq krd (vlax-curve-getPointAtParam pln (+ 1 num)))
(in_bl name_of_bl pln krd (+ 1 num) -1.0)
(setvar "Osmode"  snp) 
(setvar "CMDECHO" cmdh)
(command "_.undo" "_end")
)
    
   
   
   