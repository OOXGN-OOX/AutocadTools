;; Routine by hmsilva for merging separate hatch patterns
;; Originally posted on the AutoDesk Community Visual Lisp forum in 2013
(defun c:HatchMerge (/ ss zer ss1 hpb olde itm ent bou ss2)
  (alert
    "\n            Select hatch to Merge.\n\nFirst one will be the Properties Source."
  )
  (if (setq ss (ssget ":L" '((0 . "HATCH"))))
    (progn
      (command "_.undo" "_BE")
      (setq olde (getvar 'cmdecho)
	    hpb	 (getvar 'hpbound)
	    itm	 -1
	    ss1	 (ssadd)
	    zer	 (entlast)
      )
      (ssadd zer ss1)
      (setvar 'hpbound 0)
      (setvar 'cmdecho 0)
      (while
	(setq ent (ssname ss (setq itm (1+ itm))))
	 (command "_.-hatchedit" ent "_b" "_r" "_y")
      );; while
      (while
	(setq zer (entnext zer))
	 (ssadd zer ss1)
      );; while
      (ssdel (ssname ss1 0) ss1)
      (command "_.union" ss1 "")
      (setq bou (entlast))
      (command "_.hatch" "solid" "_l" "")
      (setq ss2 (ssget "_L"))
      (command "_.copy"
	       (ssname ss 0)
	       ""
	       "0,0,0"
	       "0,0,0"
	       "_.erase"
	       "_p"
	       ""
	       "_.matchprop"
	       "_L"
	       ss2
	       ""
	       "_.draworder"
	       ss2
	       ""
	       "_b"
	       "_.erase"
	       "_L"
	       bou
	       ss
	       ""
      )
    );; progn
  );; if
  (command "_.undo" "_E")
  (setvar 'hpbound hpb)
  (setvar 'cmdecho olde)
  (princ)
);; test