(defun C:EPP ( / pt1 pt2 blst ss i lst lst-pr tmp pl csp)
;;End Point Polyline
;;Построение полилинии, соединяющей концы выделенных объектов
;;http://forum.dwg.ru/showthread.php?t=36412

  (initget 1)
  (setq pt1 (getpoint "\nПервая точка рамки: "))
  (initget 1)
  (setq pt2 (getcorner pt1 "\nВторая точка рамки: "))
  (setq blst (list pt1 (list (car pt1)(cadr pt2)(caddr pt1)) pt2 (list (car pt2)(cadr pt1)(caddr pt1)))
        blst (mapcar '(lambda(x)(list (car x)(cadr x)))blst)
        )
  (if (setq ss (ssget "_C" pt1 pt2 '((0 . "*POLYLINE"))))
    (progn
      (setq lst nil lst-pr nil)
      (repeat (setq i (sslength ss)) ;_ end setq
        (setq pl (ssname ss (setq i (1- i))))
        (cond ((IsPointInside
                 (progn
                   (setq pt1 (vlax-curve-getStartPoint pl))
                   (setq pt2 (mapcar '+ pt1 '(0 0)))
                   )
               blst
               )
               (setq lst-pr (cons pt2 lst))
               (setq lst (cons pt1 lst))
               )
              ((IsPointInside
               (progn
                   (setq pt1 (vlax-curve-getEndPoint pl))
                   (setq pt2 (mapcar '+ pt1 '(0 0)))
                   )
               blst
               )
               (setq lst-pr (cons pt2 lst))
               (setq lst (cons pt1 lst))
               )
              (t nil)
              )
         ) ;_ end repeat
      (setq pt1 (car (GetListBoundingBox lst-pr)))
      (setq tmp
             (vl-sort-i
               lst-pr
               '(lambda(x y)
                  (< (distance pt1 x)(distance pt1 y))))
            )
      (setq lst (mapcar '(lambda(x)(nth x lst)) tmp))
      (setq csp (vla-ObjectIDToObject
                       (vla-get-ActiveDocument (vlax-get-acad-object))
                       (vla-get-OwnerID (vlax-ename->vla-object pl))))
      (if (apply '= (mapcar 'last lst))
        (progn ;_LWPOLYLINE
          (setq pt1 (caddar lst))
          (setq lst (mapcar '(lambda(x)(list (car x)(cadr x))) lst))
          (setq tmp (apply 'append lst))
          (setq tmp (vlax-make-variant (vlax-safearray-fill (vlax-make-safearray
                  vlax-vbDouble (cons 0 (1- (length tmp)))) tmp)))
          (setq tmp (vla-addLightWeightPolyline csp tmp))
          (vla-put-elevation tmp  pt1)
          )
        (progn ;_3DPOLYLINE
          (setq tmp (apply 'append lst))
          (setq tmp (vlax-make-variant (vlax-safearray-fill (vlax-make-safearray
                  vlax-vbDouble (cons 0 (1- (length tmp)))) tmp)))
           (vla-Add3DPoly csp tmp)
         )
        )
      )
    )
  (princ)
  )
(defun IsPointInside (Point Boundary / FarPoint Check)
;_* алгоритм взят на http://algolist.manual.ru/maths/geom/belong/poly2d.php
;_* На основе vk_IsPointInside
;_* Опубликовано  http://www.caduser.ru/forum/index.php?PAGE_NAME=message&FID=23&TID=36191&MID=205580&sessid=79096aca9605acaa6da486d593128e41&order=&FORUM_ID=23
;_                 http://www.arcada.com.ua/forum/viewtopic.php?p=12322
;_* Boundary - список нормализованных [т.е. только либо (X Y) либо (X Y Z)] точек
  
  ;_Проверяет Boundary на условие car и last одна и та же точка
  (if (not (equal (car Boundary)(last Boundary) 1e-6))
    (setq Boundary (append Boundary (list(car Boundary)))))
  (setq FarPoint (cons (+ (apply 'max (mapcar 'car Boundary)) 1.0)
                       (cdr Point)
                 ) ;_ end of cons
  ) ;_ end of setq
  (or
    (not
      (zerop
        (rem
          (length
            (vl-remove
              nil
              (mapcar
                (function (lambda (p1 p2) (inters Point FarPoint p1 p2))
                ) ;_ end of function
                Boundary
                (cdr Boundary)
              ) ;_ end of mapcar
            ) ;_ end of vl-remove
          ) ;_ end of length
          2
        ) ;_ end of rem
      ) ;_ end of zerop
    ) ;_ end of not
    (vl-some (function (lambda (x) x))
             (mapcar
               (function (lambda (p1 p2)
                           (or Check
                               (if (equal (+ (distance Point p1)
                                             (distance Point p2)
                                             ) ;_ end of +
                                          (distance p1 p2)
                                          1e-3) ;_ end of equal
                                 (setq Check T) nil)
                               )
                         ) ;_ end of lambda
               ) ;_ end of function
               Boundary
               (cdr Boundary)

             ) ;_ end of mapcar
    ) ;_ end of vl-some
  ) ;_ end of or
)
(defun GetListBoundingBox (pt_lst)
  (list	(apply 'mapcar (cons 'min pt_lst))
	(apply 'mapcar (cons 'max pt_lst))
  )
)