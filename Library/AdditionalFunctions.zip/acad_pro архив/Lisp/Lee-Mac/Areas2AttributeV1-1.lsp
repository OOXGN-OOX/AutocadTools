;;------------------=={ Areas 2 Attribute }==-----------------;;
;;                                                            ;;
;;  Populates a selected attribute with a Field Expression    ;;
;;  referencing the sum of the areas of selected objects.     ;;
;;------------------------------------------------------------;;
;;  Author: Lee Mac, Copyright � 2013 - www.lee-mac.com       ;;
;;------------------------------------------------------------;;
;;  Version 1.1    -    26-05-2013                            ;;
;;------------------------------------------------------------;;

(defun c:a2a ( / *error* ent fmt inc lst sel )

    (setq fmt "%lu6%qf1") ;; Field Formatting

    (defun *error* ( msg )
        (LM:endundo (LM:acdoc))
        (if (not (wcmatch (strcase msg t) "*break,*cancel*,*exit*"))
            (princ (strcat "\nError: " msg))
        )
        (princ)
    )

    (if
        (and (setq sel (ssget '((0 . "ARC,CIRCLE,ELLIPSE,HATCH,*POLYLINE,REGION,SPLINE"))))
            (progn
                (while
                    (progn (setvar 'errno 0) (setq ent (car (nentsel "\nSelect Attribute: ")))
                        (cond
                            (   (= 7 (getvar 'errno))
                                (princ "\nMissed, try again.")
                            )
                            (   (= 'ename (type ent))
                                (if (/= "ATTRIB" (cdr (assoc 0 (entget ent))))
                                    (princ "\nSelected object is not an Attribute.")
                                )
                            )
                        )
                    )
                )
                (= 'ename (type ent))
            )
        )
        (progn
            (LM:startundo (LM:acdoc))
            (if (= 1 (sslength sel))
                (vla-put-textstring (vlax-ename->vla-object ent)
                    (strcat
                        "%<\\AcObjProp Object(%<\\_ObjId "
                        (LM:ObjectID (vlax-ename->vla-object (ssname sel 0)))
                        ">%).Area \\f \"" fmt "\">%"
                    )
                )
                (progn
                    (repeat (setq inc (sslength sel))
                        (setq lst
                            (vl-list*
                                "%<\\AcObjProp Object(%<\\_ObjId "
                                (LM:ObjectID (vlax-ename->vla-object (ssname sel (setq inc (1- inc)))))
                                ">%).Area>%" " + "
                                lst
                            )
                        )
                    )
                    (vla-put-textstring (vlax-ename->vla-object ent)
                        (strcat "%<\\AcExpr " (apply 'strcat (reverse (cdr (reverse lst)))) " \\f \"" fmt "\">%")
                    )
                )
            )
            (vl-cmdf "_.updatefield" ent "")
            (LM:endundo (LM:acdoc))
        )
    )
    (princ)
)

;; ObjectID  -  Lee Mac
;; Returns a string containing the ObjectID of a supplied VLA-Object
;; Compatible with 32-bit & 64-bit systems

(defun LM:ObjectID ( obj )
    (eval
        (list 'defun 'LM:ObjectID '( obj )
            (if
                (and
                    (vl-string-search "64" (getenv "PROCESSOR_ARCHITECTURE"))
                    (vlax-method-applicable-p (vla-get-utility (LM:acdoc)) 'getobjectidstring)
                )
                (list 'vla-getobjectidstring (vla-get-utility (LM:acdoc)) 'obj ':vlax-false)
               '(itoa (vla-get-objectid obj))
            )
        )
    )
    (LM:ObjectID obj)
)

;; Start Undo  -  Lee Mac
;; Opens an Undo Group.

(defun LM:startundo ( doc )
    (LM:endundo doc)
    (vla-startundomark doc)
)

;; End Undo  -  Lee Mac
;; Closes an Undo Group.

(defun LM:endundo ( doc )
    (while (= 8 (logand 8 (getvar 'undoctl)))
        (vla-endundomark doc)
    )
)

;; Active Document  -  Lee Mac
;; Returns the VLA Active Document Object

(defun LM:acdoc nil
    (eval (list 'defun 'LM:acdoc 'nil (vla-get-activedocument (vlax-get-acad-object))))
    (LM:acdoc)
)

(vl-load-com) (princ)

;;------------------------------------------------------------;;
;;                        End of File                         ;;
;;------------------------------------------------------------;;