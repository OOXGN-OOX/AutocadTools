(defun C:E2P (/ adoc el ssnab en item lays lay lock pell ptcen)
  (setq adoc (vla-get-activedocument (vlax-get-acad-object)))
  (setq lays (vla-get-layers adoc))
  (vla-startundomark adoc)
  (setq ssnab (ssget '((0 . "ELLIPSE")))) ;_����� Ellips'�� � �������
  (setq pell (getvar "PELLIPSE"))
  (setvar "PELLIPSE" 1)

  (while (and ssnab
	      (> (sslength ssnab) 0)
	 )
    (setq el (ssname ssnab 0))
    (setq en (vlax-ename->vla-object el))
    (setq lay (vla-item lays (vla-get-layer en)))
    (if	(= (vla-get-lock lay) :vlax-true)
      (progn (vla-put-lock lay :vlax-false)
	     (setq lock (cons lay lock))
      ))
    (setq item (vla-get-ObjectName en))
    (cond
      ((= item "AcDbEllipse")
       (setq ptcen (vlax-safearray->list
		     (vlax-variant-value (vla-get-center en))
		   )
       )
       (command	"_ellipse"  "_C" ptcen
		(mapcar	'+
			ptcen
			(vlax-safearray->list
			  (vlax-variant-value (vla-get-MajorAxis en))
			))
		(mapcar	'+
			ptcen
			(vlax-safearray->list
			  (vlax-variant-value (vla-get-MinorAxis en))
			)))
       (mapcar
	 '(lambda (x y)
	    (vlax-put-property (vlax-ename->vla-object (entlast)) x y)
	  )
	 '(Linetype LineWeight Color Layer)
	 (mapcar '(lambda (x)
		    (vlax-get-property en x)
		  )
		 '(Linetype LineWeight Color Layer)
	 )
       )
       (vla-Delete en)
      )
      (t nil)
    )
    (ssdel el ssnab)
  )
  (setvar "PELLIPSE" pell)
  (if lock
    (foreach x lock (vla-put-lock x :vlax-true))
  )
  (vla-endundomark adoc)
  (princ "\n�������������� Ellipse ���������")
  (princ)
)
(princ "\n�������� � ���. ������ E2P")