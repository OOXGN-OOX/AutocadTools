(defun C:Подписи ()
  (setq pnt (getpoint "\nУкажите точку вставки: "))
  (command "_insert" (strcat botplus:library-root "/acad_pan/acad_pr/!Подписи.dwg") pnt 1 0)
)

(defun C:Роза ()
  (setq pnt (getpoint "\nУкажите точку вставки: "))
  (command "_insert" (strcat botplus:library-root "/acad_pan/acad_pr/!Роза.dwg") pnt 1 0)
)

(defun C:Обозначения ()
  (setq pnt (getpoint "\nУкажите точку вставки: "))
  (command "_insert" (strcat botplus:library-root "/acad_pan/acad_pr/!Обозначения.dwg") pnt 1 0)
)

(defun C:Миниатюры ()
  (setq pnt (getpoint "\nУкажите точку вставки: "))
  (command "_insert" (strcat botplus:library-root "/acad_pan/acad_pr/!Миниатюры.dwg") pnt 1 0)
)

(defun C:Опора_БК ()
  (setq pnt (getpoint "\nУкажите точку вставки: "))
  (command "_insert" (strcat botplus:library-root "/acad_pan/acad_pr/!Опора_БК.dwg") pnt 1 0)
)

(defun C:Опора_ПЛ ()
  (setq pnt (getpoint "\nУкажите точку вставки: "))
  (command "_insert" (strcat botplus:library-root "/acad_pan/acad_pr/!Опора_ПЛ.dwg") pnt 1 0)
)

(defun C:Пересечения ()
  (setq pnt (getpoint "\nУкажите точку вставки: "))
  (command "_insert" (strcat botplus:library-root "/acad_pan/acad_pr/!Пересечения.dwg") pnt 1 0)
)